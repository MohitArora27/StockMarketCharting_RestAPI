package com.stockmarketcharting.service;

import org.springframework.data.repository.CrudRepository;

import com.stockmarketcharting.beans.User;

public interface UserService extends CrudRepository<User, Integer>{

}
