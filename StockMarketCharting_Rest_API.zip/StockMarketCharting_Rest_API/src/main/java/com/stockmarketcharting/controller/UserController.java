package com.stockmarketcharting.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.stockmarketcharting.beans.Message;
import com.stockmarketcharting.beans.User;
import com.stockmarketcharting.service.UserService;

@RestController
public class UserController {

	
	
	 @Autowired UserService userService;
	 
	@PostMapping("/user") User create(@RequestBody User user) {
	 
	 return userService.save(user); }
	 
	 @GetMapping("/test")
		Message send() {
			return new Message("Testing REST API - T");
		}
	 
	 
	 @GetMapping("/user") Iterable<User> read() {return userService.findAll();}
	 
	 
	 @PutMapping("/user") User update(@RequestBody User user) { return
	 userService.save(user); }
	  
	  
	  @DeleteMapping("/user/{id}") void delete(@PathVariable Integer id) {
	  userService.deleteById(id); }
	 
}
